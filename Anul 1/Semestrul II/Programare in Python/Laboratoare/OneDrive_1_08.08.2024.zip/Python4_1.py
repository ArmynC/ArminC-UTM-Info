prenume = "Eric"
nume = "Idle"
varsta = 79
profesie = "comedian"
trupa = "Monty Python"

print("Salut, %s %s. Ai %s de ani. Profesia ta este %s. Ai fost membru al trupei %s." % (prenume, nume, varsta, profesie, trupa))
print("Salut, {0} {1}. Ai {2} de ani. Profesia ta este {3}. Ai fost membru al trupei {4}.".format(prenume, nume, varsta, profesie, trupa))
print(f"Salut, {prenume} {nume}. Ai {varsta} de ani. Profesia ta este {profesie}. Ai fost membru al trupei {trupa}.")