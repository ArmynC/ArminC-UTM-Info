s = "String de afisat invers."
print(f"Invers afisat string: {s[::-1]}")